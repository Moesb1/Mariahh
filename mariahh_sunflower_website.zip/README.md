# 🌻 Happy Birthday Mariahh Website

This is a simple sunflower-themed one-page site.

### To publish on GitHub Pages
1. Create a new public repository (e.g. `mariahh-sunshine`)
2. Upload the `index.html` file from this folder
3. Go to **Settings → Pages**
4. Under **Source**, select `Deploy from a branch` → choose `main` and root (`/`) folder
5. Click Save
6. After about a minute, your site will be live at:
   `https://<your-username>.github.io/mariahh-sunshine/`

### To edit the secret message
Open `index.html` in any text editor (like VS Code or Notepad), find:
```
(your secret message here 😏)
```
and replace it with your custom text.
